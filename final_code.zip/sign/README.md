# FirebaseEmailSignUp
This is the code from the Firebase: Email Sign Up, Sign In, &amp; Sign Out video tutorial.
